// TEAM

// First team member name  : Robert Valladares

// Second team member name : Danish Waheed

	To compile and run the files included vm.c scanner.c parser.c globals.h, 
the user can enter to a terminal window gcc driver.c -o extensionName to compile the .c file
then user can either specify an instructions such as -l -v -a
Once the program has finished running, it will create an output file with the
name stacktrace.txt, lexemelist.txt, lexemetable.txt, mcode.txt 

Once the program has finished. The output files will be located on the same folder as the driver.c
file.  If the program encounters an error along the process, it will terminate
and inform the user about the error and code line when possible.

To compile and execute program:
default input file name is mcode.txt
gcc driver.c -o extensionName
./extensionName (optional) 