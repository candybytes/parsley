// TEAM

// First team member name  : Robert Valladares

// Second team member name : Danish Waheed

/**
 *  parser.c
 *  this assigment will work for both assigment 3 and 4, assigment 4 requieres procedure calls
 *  and handling the if then else statement, while loops were not tested during creation of program
 *
 *  Created by Robert Valladares and Danish Waheed on 06/29/15.
 *  Copyright (c) 2015 ROBERT VALLADARES and DANISH WAHEED. All rights reserved.
 */


// Library declarations
#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"                        // import global declarations from globals.h
int trace = 0;

int m_n_inputTokens = 0;                    // used to count the amount of tokens in lexemelist.txt
int m_nCurrentToken = INVALID_INT;          // used for gettoken, store the token numerical value
char m_cCurrentTokenStr[MAX_VAR_LEN + 1];   // used for gettoken, store the token string form
int m_nTokenConstant = 0;                   // used to store the constant value when is read from linkedlist
int m_nVM_AR = 0;
int m_nVM_AR_Index = 0;

int m_nListIndex = 0;                       //  used as linkedlist index;
int m_nTokVarFlag = 0;                      // use to flag if token is variable or constant
int m_nVariableStackAdrx = 4;               // variables start of address of first AR
int m_nAR_Level = 0;                        // Activation Record first Level = 0;
int m_nAR_LookUp = 0;                       // Activation record look up for existVar, existConst, existProc
int m_nAR_Found = 0;                        // used during variable, constant proc search, outside of declarations
int m_nARLoop = 0;                          // used to loop in the search of records
int m_nProcCall = 1;
#define MAX_AR_LEVELS 10                    // maximum amount of procedure AR levels

struct NODE *gListHead = NULL;              // global list head for parsing
struct NODE *gFreeListHead = NULL;          // global list head in case of error printing, free malloc from this pointer

#define MAX_CODE_LENGTH 500                 // max amount of tokenized instructions symbols
int OTC = 0;                                // Output to Console Flag

int m_nVarCount = 0;                        // keep track of how many variables are declared
int m_nConstCount = 0;                      // keep track of how many constants are declared
int m_nProcCount = 0;                       // keep track of how many procedure are declared

// there will be at most m_nCleanCount separate namerecord_t tokens
namerecord_t namerecord_table[MAX_AR_LEVELS][MAX_CODE_LENGTH];  // ARs token array
int m_nNameRecordCount = 0;                                     // index for ARs token array
int m_nTempNameRecordCount = 0;                                 // temp to store AR name record count at proc declaration

struct instructions codeLines[MAX_AR_LEVELS][MAX_CODE_LENGTH]; // instructions array

int m_nCodeLineCount = 0;                                       // index for code line genetator
int m_nIfCodeLine = 0;
int m_nProcTempCodeLine = 0;
int procCalls[10]={0,0,0,0,0,0,0,0,0,0};                        // keep track of homany times a procedure is call
int LevelFound = 0, nLevel;
int currentCodeLine = 0;
int beginWhileLine = 0;
int endWhileLine = 0;
int nRecordFoundIndex = 0;
int vmAR = 0;
int vmARIndex = 0;

char m_cErrorTokenStr[MAX_VAR_LEN + 1];   // used for identifying the error token
int LineNumber = 0;
int TokenCount = 0;
int Translate = 0;
#define MAX_NUMBER_LINES 1000
int lexemeLine[MAX_NUMBER_LINES] = {0};



//--------------------local data structures ---------------


typedef struct NODE{
    char token[MAX_VAR_LEN + 1];
    struct NODE *next;
} NODE;

// function declaration look ahead

NODE *NewNode(char str[]);                              // create a new linked list, new linkedlist node
NODE *InsertAtTail(NODE *head, char str[]);             // insert a new node at the tail of the list
void initializeNamerecord_table();                      // initialize the array of const var procs
void initializeInstructions();                          // initialize the array of const var procs

void FreeMemoryAllocFront_to_Tail();                    // free the space allocated to avoid seg fault

void procedure_PROGRAM();                               // analyze the read prgram
void getNextTokenNode();                                // update global int token m_nCurrentToken, and str token m_cCurrentTokenStr
void process_Block();                                   // BLOCK
void const_decl();                                      // procedure_PROGRAM sub procedure, constants declarations
void var_decl();                                        // procedure_PROGRAM sub procedure, variables declarations
void proc_decl();                                       // procedure_PROGRAM sub procedure, procedure declarations

void process_STATEMENT();                               // STATEMENT
void process_EXPRESSION();                              // EXPRESSION
void process_TERM();                                    // TERM
void process_FACTOR();                                  // FACTOR
void process_CONDITION();                               // CONDITION

int strsAreEqual(char * stt1, char *str2);              // are two string equa;
int existVar(char varName[]);                           // does a variable  by the name passed exist, return the index where found
int existConst(char constName[]);                       // does a constant  by the name passed exist, return the index where found
int existProc(char procName[]);                         // does a procedure by the name passed exist, return the index where found
void enterCode(int OPcode, int Lval, int Mval);         // enter the vm code line passed by values

void fixLineNumbers();
void printCodeLinesTOFILE();                            // print the vm code lines to output file mcode.txt
void printCodeLines();                                  // print the vm code lines to console, uses OTC flag
char *FILECLEANUP[] = {"mcode.txt"};
FILE *ifp = NULL;
// read input token lines count
void InputTokenLines();


// -----------------Initial call to program  -----------------
int main(int argc, char *argv[]) {
    int i = 0;
    
    
    ifp = fopen("lexemelist.txt", "r");
    if (ifp == NULL) {
        printError(err35, " ");
    }
    
    if(argc > 1) {
        OTC = strsAreEqual(argv[1], "-a");
        
    }
    // read how many tokens per line
    InputTokenLines();
    initializeNamerecord_table();
    initializeInstructions();
    
    // create a new ListHead
    NODE *ListHead = NULL;
    
    // will do linked list of char* to store each token without knowing count of tokens
    // and have a local-global token counter
    // all tokens no matter what, will be max length of 12
    char iToken[MAX_VAR_LEN + 1];  // One extra for nul char. //
    
    while (fscanf(ifp, "%s", iToken) != EOF) {
        //create a new node of linked list with string
        // or add them to a char * array, less code
        ListHead = InsertAtTail(ListHead, iToken);
        m_n_inputTokens++; // increase the count of token read in
        
    }
    
    // close the input file
    fclose(ifp);
    // call to analyse tokens -- parser
    procedure_PROGRAM();
    // clean up after using the read tokens, you need to free the calloc space
    // when you are done with it. Defaul call to free malloc
    //  at error printing, the program will also try to free the malloc in case program does not reach this point
    if(gFreeListHead != NULL) { FreeMemoryAllocFront_to_Tail(gFreeListHead); gFreeListHead = NULL;}
    // default printing statement to let user know that the program contains no code or gramaticall errors
    printf("\n\nNo errors, program is syntactically correct.\n\n");
    
    //printCodeLines();       // ----WARNING, REMOVE BEFORE SUBMITTING
    printCodeLinesTOFILE(); // always print code lines to file
    
    if (OTC) {
        printCodeLines();
    }
    
    return 0;
}


//-----------------start -- read tokens in --------------------------
/*
 *  struct node *NewNode(int nData)
 *  create a new LinkedList node, inserting the value that was passed
 *  return the pointer of the new created node
 */
NODE *NewNode(char str[]){
    
    // create a memory space to store the node
    NODE *brandNewNode = NULL;
    brandNewNode = malloc(sizeof(NODE) );
    // check if malloc was successful
    if (brandNewNode != NULL) {
        // store the value pass in nData
        strcpy(brandNewNode->token, str);
        brandNewNode->token[MAX_VAR_LEN] = '\0';
        // set the node next pointer to null
        brandNewNode->next = NULL;
        
    } else {
        // malloc failed, ptr is still null
        printError(err30, "202");
    }
    // return the pointer to the new created node, or NULL if it failed to malloc space
    return brandNewNode;
}

/*
 *  struct node *InsertAtTail(struct node *head, int data)
 *  insert a value at the tail of a linked list, return the
 *  same pointer that was passed, if the passed pointer is null
 *  creare a new list and return the head of the list
 */
NODE *InsertAtTail(NODE *head, char str[]){
    // check if head is null, if true, create new linked list
    if (head == NULL) {
        head = NewNode(str);
        gFreeListHead = head;
        gListHead = head;
        // check if creating a new list failed
        if (head == NULL) {
            printError(err30, "222");
            
        }
        // if the head was null, a new list was created, return pointer to new list
        return head;
        
    }
    
    // create a new node to be added to the tail
    NODE *newTailNode = NULL;
    newTailNode = NewNode(str);
    if (newTailNode == NULL) {
        printError(err30, "234");
    }
    // check if you are at the tail before inserting
    NODE *current = head;
    // run the while loop until you hit a node->next that is null
    while (current->next != NULL) {
        // loop until you find the tail of the list
        current = current->next;
    }
    
    // the tail node next gets the new node
    current->next = newTailNode;
    // return the original node passed
    return head;
}

/*
 * FreeMemoryAllocFront_to_Tail(struct node *head)
 * free all callor or malloc created, start at the node passed
 * and move forward freeing the memory as you go
 * free the last node at the end of last recursion
 */
void FreeMemoryAllocFront_to_Tail(NODE *head){
    
    if  (head == NULL){
        // empty list or node
        return;
    }
    // if the head was not null
    // then check if a leaf, if not a leaf, then
    // recursion on the next node and free the current
    NODE *current = NULL;
    
    if(head->next != NULL){
        current = head->next;
        free(head);
        head = NULL;
        FreeMemoryAllocFront_to_Tail(current);
    } else {
        // free the last node or leaf
        free(head);
        head = NULL;
    }
    
    return;
    
}

//-----------------end -- read tokens in -------------------------------

// ------------------start of analyze tokens ---------------------------

/*
 *  procedure_PROGRAM()
 *  analyze the PM/O PL/0 program and generate the code
 *  when done, realign the VM code lines and assign the jumps, and call offsets
 */
void procedure_PROGRAM(){
    
    getNextTokenNode();
    process_Block();
    // program should have ended after processing code block, look for periodsym
    if (m_nCurrentToken != periodsym) {
        printError(err9, NULL);
    }
    enterCode(sio, 0, 2);
    fixLineNumbers();
    
    return;
}
/*
 *  getNextTokenNode()
 *  this will get the next token in the input structure array
 *  if the token is a sign of a name, it will store the name and skip
 *  if the token is a sign of a numerical value, it will store the value and skip
 */
void getNextTokenNode(){
    if (TokenCount >= lexemeLine[LineNumber] ) {
        LineNumber++;
        TokenCount = 0;
    }
    
    strcpy(m_cCurrentTokenStr,"");          // reset to  empty string "" the string token
    m_nTokenConstant = 0;                   // reset the token constant value
    // check that the list, and tokens are withing limits
    if (gListHead != NULL && m_nListIndex < m_n_inputTokens) {
        // copy the token char string for error printing
        strcpy(m_cErrorTokenStr,gListHead->token);
        // transform the token to its integer value
        m_nCurrentToken = atoi(gListHead->token);
        gListHead = gListHead->next;        // move the pointer of the linkedlist to next
        m_nListIndex++;                     // indicate the linkedlist index
        TokenCount++;                       // keep track of the line token count
        Translate = 1;                      // translate the token to its string representation
        if (m_nCurrentToken == becomessym) {TokenCount++;} // := is counted as two tokens :, =
        
        if (m_nCurrentToken == identsym) {  // is the token just read the indication of a string name
            // copy the string name
            strcpy(m_cCurrentTokenStr,gListHead->token);
            strcpy(m_cErrorTokenStr,gListHead->token);
            gListHead = gListHead->next;    // move the pointer of the linkedlist to next
            m_nListIndex++;                 // indicate the linkedlist index
            Translate = 0;                  // translate the token to its string representation
            
        }
        
        if (m_nCurrentToken == numbersym) { // is the token just read the indication of a constant value
            // copy the constant value
            m_nTokenConstant = atoi(gListHead->token);
            strcpy(m_cErrorTokenStr,gListHead->token);
            gListHead = gListHead->next;    // move the pointer of the linkedlist to next
            m_nListIndex++;                 // indicate the linkedlist index
            Translate = 0;                  // translate the token to its string representatio
        }
        
        return;
    }
    
    printError(err35, "353");              // error reading token from linked list
    
    return;
}

void process_Block(){
    
    // is current token a valid token?
    if (m_nCurrentToken == INVALID_INT || gListHead == NULL) {
        printError(err35, "362");
        return;
    }
    
    if (m_nCurrentToken == constsym){
        // token constant declaration constsym = 28
        const_decl();
    }
    
    if (m_nCurrentToken == varsym){
        // token is variable declaration = 29
        var_decl();
    }
    
    if (m_nCurrentToken == procsym){
        // token Procedure declaration = 30
        proc_decl();
    }
    
    process_STATEMENT();
    return;
    
}
/*
 *  const_decl()
 *  handle constant declarations for the current activation record
 *  will check only at active AR if name of constant already exist as variable, constant or
 *  procedure
 */
void const_decl(){
    
    namerecord_t singleNamerecord;  // single Var, Const or Proc record
    
    if ( gListHead == NULL){
        // error reading the current token from getNextTokenNode
        printError(err35, "397");
        return;
    }
    
    do {
        
        getNextTokenNode();
        
        if (m_nCurrentToken != identsym) {
            printError(err36, "406");
        }
        
        m_nARLoop = 0; // set up name search to loop = false
        // check if constant exist already as variable, constant or procedure
        if ( existVar(m_cCurrentTokenStr) || existConst(m_cCurrentTokenStr) || existProc(m_cCurrentTokenStr) ){
            // error constant already declared as a variable or procedure name
            printError(err45, "413");
        }
        
        // copy the name of the constant
        strcpy(singleNamerecord.name, m_cCurrentTokenStr);
        // set the type of the constant
        singleNamerecord.kind = lexConstant;
        
        getNextTokenNode();
        
        if (m_nCurrentToken != eqlsym) {
            printError(err3, "424");
        }
        
        getNextTokenNode();
        
        if (m_nCurrentToken != numbersym) {
            printError(err2, "430");
        }
        
        singleNamerecord.val = m_nTokenConstant;
        // set the address of the constant
        singleNamerecord.adr = -1;
        // set the lelvel of the constant
        singleNamerecord.level = m_nAR_Level;
        // set the vm code line of the constant
        singleNamerecord.Line = m_nCodeLineCount;
        // store the created single Name record into the array
        namerecord_table[m_nAR_Level][m_nNameRecordCount++] = singleNamerecord;
        m_nConstCount++;
        // token could be coma or semicolon , ;
        getNextTokenNode();
        
    } while (m_nCurrentToken == commasym);
    
    if (m_nCurrentToken != semicolonsym) {
        printError(err37, "449");
    }
    
    getNextTokenNode();
    
    return;
}
/*
 *  var_decl()
 *  handle variable declarations for the current activation record
 *  will check only at active AR if name of variable already exist as variable, constant or
 *  procedure
 */
void var_decl(){
    
    namerecord_t singleNamerecord;  // single Var, Const or Proc record
    
    if ( gListHead == NULL){
        // error reading the current token from getNextTokenNode
        printError(err35, "468");
        return;
    }
    
    do {
        getNextTokenNode();
        
        if (m_nCurrentToken != identsym) {
            printError(err36, "476");
        }
        
        m_nARLoop = 0; // set up name search to loop = false
        
        if ( existVar(m_cCurrentTokenStr) || existConst(m_cCurrentTokenStr) || existProc(m_cCurrentTokenStr) ){
            // error variable already declared as a variable or procedure name
            printError(err46, "483");
        }
        
        // copy the name of the variable
        strcpy(singleNamerecord.name, m_cCurrentTokenStr);
        // set the type of the record
        singleNamerecord.kind = lexVar;
        
        // set the value of the variable
        singleNamerecord.val = 0;
        // set the address of the constant
        singleNamerecord.adr = m_nVariableStackAdrx;
        m_nVarCount++;
        // set the lelvel of the constant
        singleNamerecord.level = m_nAR_Level;
        // set the vm code line of the constant
        singleNamerecord.Line = m_nCodeLineCount;
        
        // store the created single Name record into the array
        namerecord_table[m_nAR_Level][m_nNameRecordCount++] = singleNamerecord;
        
        getNextTokenNode();
        
        m_nVariableStackAdrx++;
        
    } while (m_nCurrentToken == commasym );
    
    if (m_nCurrentToken != semicolonsym) {
        printError(err37, "511");
    }
    enterCode(inc, 0, 4 + m_nVarCount);
    getNextTokenNode();
    
    return;
    
}

void proc_decl(){
    
    namerecord_t singleNamerecord;  // single Var, Const or Proc record
    int procCodeLines = m_nCodeLineCount;
    
    if ( gListHead == NULL){
        // error reading the current token from getNextTokenNode
        printError(err35, "527");
        return;
    }
    
    while (m_nCurrentToken == procsym) {
        // update the current token value and get the node pointer to next token
        getNextTokenNode();
        
        if (m_nCurrentToken != identsym) {
            printError(err38, "536");
        }
        m_nARLoop = 0; // set up name search to loop = false
        // check if variable exist already as variable, constant or procedure
        if ( existVar(m_cCurrentTokenStr) || existConst(m_cCurrentTokenStr) || existProc(m_cCurrentTokenStr) ){
            printError(err47, "541");
        }
        
        strcpy(singleNamerecord.name, m_cCurrentTokenStr); // copy the name of the procedure
        
        singleNamerecord.kind = lexProc; // set the type of the record
        
        singleNamerecord.val = 0;       // set the value of the procedure
        
        singleNamerecord.adr = 0;       // set the address of the procedure
        
        singleNamerecord.level = m_nAR_Level; // set the lelvel of the procedure
        // set the vm code line of the constant
        singleNamerecord.Line = m_nCodeLineCount;
        singleNamerecord.procNumber = m_nProcCount + 1;
        
        // store the created single Name record into the array
        namerecord_table[m_nAR_Level][m_nNameRecordCount++] = singleNamerecord;
        
        
        
        
        
        
        m_nAR_Level++;  // increase the level for each new procedure call
        m_nProcCount++; // increase the count of procedures declarations in the program
        m_nTempNameRecordCount = m_nNameRecordCount;
        m_nNameRecordCount = 0;     // reset the count for the new procedure 7/22/15
        m_nVariableStackAdrx = 0;   // added 7/22/15
        m_nVariableStackAdrx += 4;  // increase the variables starting address 7/22/15
        m_nVarCount = 0;            // added 7/20/15, to reset the count of variables in activation record
        m_nConstCount = 0;
        m_nProcTempCodeLine = m_nCodeLineCount;
        
        getNextTokenNode();
        
        if (m_nCurrentToken != semicolonsym) {
            printError(err39, "578");
        }
        
        // get next token, increase the L level, call block procedure again
        getNextTokenNode();
        
        // ** when increasing the AR level, you must also increase the stack space
        process_Block();
        
        if (m_nCurrentToken != semicolonsym) {
            printError(err40, "588");
        }
        
        getNextTokenNode();
    }
    
    procCodeLines = m_nCodeLineCount - procCodeLines;
    
    enterCode(opr, 0, 0); // return from procedure
    // return to the previous AR after exiting procedure processing
    if (m_nAR_Level) {
        m_nAR_Level--;
    }
    
    m_nNameRecordCount = m_nTempNameRecordCount;
    
    return;
    
}


void process_STATEMENT(){
    
    //struct instructions singleCodeLineRecord;
    
    int ifvmAR, ifvmARIndex;
    
    if ( gListHead == NULL){
        printError(err35, "616");
        return;
    }
    
    switch (m_nCurrentToken) {
            
        case identsym:      // token is of kind identsym
            m_nARLoop = 1; // loop trhu AR to see if variable is declared in current AR or parent AR
            
            if ( !( nRecordFoundIndex = existVar(m_cCurrentTokenStr) )){
                printError(err11, "626");
            }
            // fix the offset return from existVar i + 1;
            nRecordFoundIndex -= 1;
            nLevel = (m_nAR_Level - m_nAR_Found);
            
            getNextTokenNode();
            // if token <> " := "   error
            if (m_nCurrentToken != becomessym) {
                printError(err41, "625");
            }
            // gettoken
            getNextTokenNode();
            // expression
            process_EXPRESSION();
            // create a code line for VM
            //LevelFound = m_nAR_Level - namerecord_table[m_nAR_Found][nRecordFoundIndex].level;
            enterCode(sto, nLevel, namerecord_table[m_nAR_Found][nRecordFoundIndex].adr);
            
            break;
        case callsym:
            
            getNextTokenNode();
            // if token <> " identsym " error
            if (m_nCurrentToken != identsym) {
                printError(err36, "651");
            }
            // check if procedure exist or not, if it does not exit, error11
            if ( !(nRecordFoundIndex = existProc(m_cCurrentTokenStr) ) ){
                printError(err48, "655");
            }
            nRecordFoundIndex -= 1;
            // create a code line for VM
            enterCode(cal, 0, 0);
            vmAR = m_nVM_AR;
            vmARIndex = m_nVM_AR_Index;
            codeLines[vmAR][vmARIndex].procNumberId = namerecord_table[m_nAR_Found][nRecordFoundIndex].procNumber;
            codeLines[vmAR][vmARIndex].Called = (m_nAR_Found - vmAR ? 1 : 0); // has this procedure been called before
            
            getNextTokenNode();
            
            break;
            
        case beginsym:
            
            getNextTokenNode();
            process_STATEMENT();
            
            while (m_nCurrentToken == semicolonsym) {
                getNextTokenNode();
                process_STATEMENT();
            }
            // if token <> "end" error
            if (m_nCurrentToken != endsym) {
                printError(err42, "680");
            }
            
            getNextTokenNode();
            break;
            
        case ifsym:
            
            // token is of kind ifsym
            getNextTokenNode();
            // condition
            process_CONDITION();
            // if token <> "then" error
            if (m_nCurrentToken != thensym) {
                printError(err16, "694");
            }
            // get current VM codeLine
            currentCodeLine = m_nIfCodeLine = m_nCodeLineCount;
            
            // create a code line for VM
            enterCode(jpc, 0, 0);
            // gettoken
            ifvmAR = vmAR = m_nVM_AR;
            ifvmARIndex = vmARIndex = m_nVM_AR_Index;
            
            getNextTokenNode();
            //statement
            process_STATEMENT();
            
            codeLines[ifvmAR][ifvmARIndex].jOffset = m_nCodeLineCount - m_nIfCodeLine;
            break;
            
        case elsesym:
            codeLines[vmAR][vmARIndex].jOffset += 1;
            
            currentCodeLine = m_nIfCodeLine = m_nCodeLineCount;
            enterCode(jpc, 0, 0);
            vmAR = m_nVM_AR;
            vmARIndex = m_nVM_AR_Index;
            // gettoken
            getNextTokenNode();
            // get current VM codeLine
            currentCodeLine = m_nCodeLineCount;
            
            //statement
            process_STATEMENT();
            break;
            
        case whilesym:
            
            // token is of kind whilesym
            // at what line did while loop start
            beginWhileLine = m_nCodeLineCount;
            // gettoken
            getNextTokenNode();
            //condition
            process_CONDITION();
            // at what line did while loop end
            endWhileLine = m_nCodeLineCount;
            // create a code line for VM
            enterCode(jpc, 0, 0);
            vmAR = m_nVM_AR;
            vmARIndex = m_nVM_AR_Index;
            
            // if token <> "dosym" error
            if (m_nCurrentToken != dosym) {
                printError(err18, "746");
            }
            // gettoken
            getNextTokenNode();
            //statement
            process_STATEMENT();
            enterCode(jmp, 0, beginWhileLine);
            codeLines[vmAR][vmARIndex].jOffset = m_nCodeLineCount - endWhileLine;
            
            break;
            
        case writesym:
            
            getNextTokenNode();
            // loop trhu AR to see if variable is declared in current AR or parent AR
            m_nARLoop = 1;
            
            if (m_nCurrentToken != identsym) {
                // token was not identifier
                printError(err50, "765");
            }
            nRecordFoundIndex = 0;
            
            // check if variable exist already as variable, constant
            if ( (nRecordFoundIndex = existVar(m_cCurrentTokenStr)) || (nRecordFoundIndex = existConst(m_cCurrentTokenStr)) ){
                // fix the offset of 1, i + 1 from the return
                nRecordFoundIndex -= 1;
                nLevel = (m_nAR_Level - m_nAR_Found);
                // get the record information
                if (namerecord_table[m_nAR_Found][nRecordFoundIndex].kind == lexConstant) { // constant
                    enterCode(lit, 0, namerecord_table[m_nAR_Level][nRecordFoundIndex].val);
                }
                if (namerecord_table[m_nAR_Found][nRecordFoundIndex].kind == lexVar) {      // variable
                    enterCode(lod, nLevel, namerecord_table[m_nAR_Found][nRecordFoundIndex].adr);
                }
                // enter new VM code for SIO
                enterCode(sio , 0, 0);
                
                getNextTokenNode();
                break;
                
            } else {
                printError(err51, "788");
                break;
            }
            
            break;
            
        case readsym:
            
            getNextTokenNode();
            
            if (m_nCurrentToken != identsym) {
                printError(err49, "799");
            }
            
            nRecordFoundIndex = 0;
            m_nARLoop = 1; // loop trhu AR to see if variable is declared in current AR or parent AR
            if ( ! (nRecordFoundIndex = existVar(m_cCurrentTokenStr)) ){
                printError(err12, "805");
                
            }
            nRecordFoundIndex -= 1; // reset the offset from existVar return i + 1
            nLevel = (m_nAR_Level - m_nAR_Found);
            // create a code line for VM read
            enterCode(sio, 0, 1);
            // create a code line for VM store
            enterCode(sto, 0, namerecord_table[m_nAR_Found][nRecordFoundIndex].adr);
            
            getNextTokenNode();
            
            break;
            
    } // end switch
    
    
}

void process_EXPRESSION(){
    
    int nOp = 0;
    
    if ( gListHead == NULL){
        // need to do error number here for failed to read lexemelist token
        printError(err35, "830");
        // always must return something
        return;
    }
    
    if ( (m_nCurrentToken == plussym) || (m_nCurrentToken == minussym) ) {
        // store the negative or possive mark
        nOp = m_nCurrentToken;
        
        getNextTokenNode();
        
        process_TERM(); // TERM
        
        if (nOp == minussym){
            // create a code line for VM negation
            enterCode(opr, 0, neg); // this is a negation
        }
        
    } else {
        
        process_TERM(); // TERM
    }
    
    while ( (m_nCurrentToken == plussym) || (m_nCurrentToken == minussym) ) {
        
        nOp = m_nCurrentToken;
        
        getNextTokenNode();
        
        process_TERM(); // TERM
        enterCode(opr, 0, g_naArithOPLookup[nOp]);
        
    }
    
    return;
    
}

void process_TERM(){
    
    int nOp = 0;
    
    if ( gListHead == NULL){
        // need to do error number here for failed to read lexemelist token
        printError(err35, "874");
        // always must return something
        return;
        
    }
    // factor
    process_FACTOR();
    
    while ( (m_nCurrentToken == multsym) || (m_nCurrentToken == slashsym) ) {
        nOp = m_nCurrentToken;
        // get token
        getNextTokenNode();
        
        process_FACTOR(); // FACTOR
        
        enterCode(opr, 0, g_naArithOPLookup[nOp]);
        
    }
    // return to TERM caller
    return;
}

/*
 *  process_CONDITION()
 *
 */
void process_FACTOR(){
    
    int nRecordFoundIndex = 0;
    int nLevel = 0;
    
    
    if ( gListHead == NULL){
        // need to do error number here for failed to read lexemelist token
        printError(err35, "908");
        // always must return something
        return;
    }
    
    switch (m_nCurrentToken) {
            
        case identsym:
            
            m_nARLoop = 1; // loop trhu AR to see if variable is declared in current AR or parent AR
            // check if variable exist or not, if it does not exit, error11
            
            if ( (nRecordFoundIndex = existVar(m_cCurrentTokenStr)) || (nRecordFoundIndex = existConst(m_cCurrentTokenStr)) ){
                nRecordFoundIndex -= 1; // adjust the offset from existVar or existConst return of i + 1 ;
                nLevel = (m_nAR_Level - m_nAR_Found);
                
                if (namerecord_table[m_nAR_Found][nRecordFoundIndex].kind == lexConstant){
                    enterCode(lit, 0, namerecord_table[m_nAR_Found][nRecordFoundIndex].val);
                }
                
                if (namerecord_table[m_nAR_Found][nRecordFoundIndex].kind == lexVar){
                    enterCode(lod  , nLevel, namerecord_table[m_nAR_Found][nRecordFoundIndex].adr);
                }
                
            } else {
                // variable or constant is not declared
                printError(err11, "934");
            }
            
            getNextTokenNode();
            
            break;
            
        case numbersym:
            
            enterCode(lit  , 0, m_nTokenConstant);
            
            getNextTokenNode();
            
            break;
        case lparentsym:
            
            getNextTokenNode();
            
            process_EXPRESSION(); // EXPRESSION
            
            if (m_nCurrentToken != rparentsym) {
                printError(err43, "955");
            }
            
            getNextTokenNode();
            
            break;
            
        default:
            printError(err44, "963");
            break;
            
    }
    
    return;
}
/*
 *  process_CONDITION()
 *  analyze the continional statements from the PL/0 PM/0 program
 */
void process_CONDITION(){
    
    int nOp = 0;
    
    if ( gListHead == NULL){
        printError(err35, "979");
        // always must return something
        return;
    }
    
    if (m_nCurrentToken == oddsym) {
        
        nOp = m_nCurrentToken;
        // gettoken
        getNextTokenNode();
        // expression
        process_EXPRESSION();
        
        enterCode(opr, 0, odd);
        
    } else {
        // expression
        process_EXPRESSION();
        // if token <> relation, error
        if ( (m_nCurrentToken < eqlsym) || (m_nCurrentToken > geqsym) ){
            printError(err20, " ");
        }
        nOp = m_nCurrentToken;
        // gettoken
        getNextTokenNode();
        // expression
        process_EXPRESSION();
        // look up and enter what op code for equalities will be use by the VM
        enterCode(opr, 0, g_naArithOPLookup[nOp]);
    }
    
    return;
    
}
/*
 *  initializeInstructions()
 *  set the default values for the codeLines table
 */
void initializeInstructions(){
    // initialize instructions table to default 0's
    int i = 0;
    int j = 0;
    for (j = 0; j < MAX_AR_LEVELS; j++) {
        
        for (i = 0; i < MAX_CODE_LENGTH ; i++) {
            
            codeLines[j][i].OP = -1;
            codeLines[j][i].L = 0;
            codeLines[j][i].M = 0;
            codeLines[j][i].Line = -1;
            codeLines[j][i].procNumberId = -1;   //used for when calls to procedure are made
            codeLines[j][i].Called =0;          // used to know if it is initial call or subsequent calls
            codeLines[j][i].jOffset = -1;     // used to kknow the jumping ahead offset
        }
        
    }
    return;
}

/*
 *  initializeNamerecord_table(namerecord_t *record_table)
 *  set the default values for the namerecord_t record_table
 *  check that strcpy was valid for the char arrray
 */
void initializeNamerecord_table(){
    // initialize tokens record table
    int i = 0;
    int j = 0;
    for (j = 0; j < MAX_AR_LEVELS; j++) {
        
        for (i = 0; i < MAX_CODE_LENGTH ; i++) {
            namerecord_table[j][i].kind = 0;           // constant = 1; var = 2, proc = 3
            if ( strcpy(namerecord_table[j][i].name, "") == NULL) {
                printError(err33, "1052");
            };                                      // name up to 11 characters long, 11 + 1 for \0
            namerecord_table[j][i].val = 0;            // number (ASCII value)
            namerecord_table[j][i].level = 0;          // L level
            namerecord_table[j][i].adr = 0;            // M address
            namerecord_table[j][i].Line = -1;            // M address
            namerecord_table[j][i].procNumber = -1;            // M address
            
            
        }
    }
    return;
    
}

/*
 *  existVar(char varName[])
 *  determine if a variable name already exist
 *  if m_nARLoop == 1, then loop thru all Activation records (calling), else only the active AR (declaration)
 *  returns the index of the array and sets the level where name is found
 */
int existVar(char varName[]){
    
    int i = 0, j = 0;
    m_nAR_LookUp = m_nAR_Level;
    m_nAR_Found = m_nAR_LookUp;
    
    do {
        
        m_nAR_Found = m_nAR_LookUp;
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (namerecord_table[m_nAR_LookUp][i].kind == 0){ i = MAX_CODE_LENGTH; }
            if ( strsAreEqual(namerecord_table[m_nAR_LookUp][i].name, varName) & (namerecord_table[m_nAR_LookUp][i].kind == lexVar) ) {
                return i + 1;
            }
        }
        m_nAR_LookUp--;
        
    } while (m_nARLoop && (m_nAR_LookUp >= 0) );
    
    return 0;
}

/*
 *  existConst(char constName[])
 *  determine if a constant name already exist
 *  if m_nARLoop == 1, then loop thru all Activation records (calling), else only the active AR (declaration)
 *  returns the index of the array and sets the level where name is found
 */
int existConst(char constName[]){
    
    
    int i = 0, j = 0;
    m_nAR_LookUp = m_nAR_Level;
    m_nAR_Found = m_nAR_LookUp;
    
    do {
        m_nAR_Found = m_nAR_LookUp;
        
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (namerecord_table[m_nAR_LookUp][i].kind == 0){ i = MAX_CODE_LENGTH; }
            if ( strsAreEqual(namerecord_table[m_nAR_LookUp][i].name, constName) & (namerecord_table[m_nAR_LookUp][i].kind == lexConstant) ) {
                return i + 1;
            }
        }
        
        m_nAR_LookUp--;
        
    } while (m_nARLoop && (m_nAR_LookUp >= 0) );
    
    return 0;
}

/*
 *  existProc(char procName[])
 *  determine if a procedure name already exist
 *  if m_nARLoop == 1, then loop thru all Activation records (calling), else only the active AR (declaration)
 *  returns the index of the array and sets the level where name is found
 */
int existProc(char procName[]){
    
    int i = 0, j = 0;
    m_nAR_LookUp = m_nAR_Level;
    m_nAR_Found = m_nAR_LookUp;
    
    do {
        m_nAR_Found = m_nAR_LookUp;
        
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (namerecord_table[m_nAR_LookUp][i].kind == 0){ i = MAX_CODE_LENGTH; }
            if ( strsAreEqual(namerecord_table[m_nAR_LookUp][i].name, procName) & (namerecord_table[m_nAR_LookUp][i].kind == lexProc) ) {
                return i + 1;
            }
        }
        m_nAR_LookUp--;
        
    } while (m_nARLoop && (m_nAR_LookUp >= 0) );
    
    return 0;
}

/*
 *  strsAreEqual(char * stt1, char *str2)
 *  compare two character arryas with strcmp
 *  return 1 if they are the same string, else return 0
 */
int strsAreEqual(char * stt1, char *str2){
    // if the two strings are equal, returns 1, else returns 0
    return strcmp(stt1, str2) == 0;
}


// ------------------end of analyze tokens ---------------------------

// ------------------code processing ------------------------

/*
 * enterCode(int nOPcode, int nLcode, int nMcode)
 * additional arguments m_nCodeLineCount, m_nAR_Level
 * enter VM code information such as jump 0 M, or Add 0 0
 */
void enterCode(int nOPcode, int nLcode, int nMcode){
    int i = 0;
    
    while (codeLines[m_nAR_Level][i].OP != -1) {
        i++;
    }
    
    // store the values into struct array
    codeLines[m_nAR_Level][i].OP = nOPcode;
    codeLines[m_nAR_Level][i].L = nLcode;
    codeLines[m_nAR_Level][i].M = nMcode;
    codeLines[m_nAR_Level][i].Line = m_nCodeLineCount;
    codeLines[m_nAR_Level][i].AR = m_nVM_AR = m_nAR_Level;
    codeLines[m_nAR_Level][i].AR_Index = m_nVM_AR_Index = i;
    
    m_nCodeLineCount++;
    
    return;
}
/*
 *  printCodeLinesTOFILE()
 *  this will always be called
 *  and print the codeline structure array in ascending order
 */

void printCodeLines(){
    int i = 0;
    printf("VM Code Lines mcode.txt\n");
    printf("%4s%3s%3s%3s\n","Line","OP","L","M");
    int j = 0;
    int printOffset = 0;
    if (m_nProcCount) {
        printOffset = 0;
    }
    for (j = 0; j <= m_nProcCount-printOffset ; j++) {
        
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (codeLines[j][i].OP == -1) {
                continue;
            }
            printf("%4d%3d%3d%3d\n",codeLines[j][i].Line, codeLines[j][i].OP, codeLines[j][i].L, codeLines[j][i].M);
        }
        
    }
    printf("\n");
}
/*
 *  printCodeLinesTOFILE()
 *  this will always be called
 *  and print the codeline structure array in ascending order
 */
void printCodeLinesTOFILE(){
    
    FILE * fp = NULL;
    fp = fopen("mcode.txt","w");
    int i = 0;
    int j = 0;
    
    for (j = 0; j <= m_nProcCount; j++) {
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (codeLines[j][i].OP == -1) {
                continue;
            }
            fprintf(fp,"%3d%3d%3d\n", codeLines[j][i].OP, codeLines[j][i].L, codeLines[j][i].M);
        }
    }
    fprintf(fp,"\n");
    // close the file
    fclose(fp);
    
}

/*
 *  printError(int ErrorNumber)
 *  Print the string that is represented by the error number passed
 */
void printError(int ErrorNumber, char *strToken){
    int i = 0;
    
    // print the error message given an error number from g_caErrorMsgs[] char* array
    if (ErrorNumber <= MAX_ERROR) {
        // to find error string, substract offset of 1
        
        printf("Error %d, %s\n", ErrorNumber, g_caErrorMsgs[ErrorNumber - 1]);
        if (Translate) {
            strcpy(m_cErrorTokenStr,m_sa_token_Strings[m_nCurrentToken -1]);
        }
        printf("Possible Error at Input.txt aproximate line # %d, position # %d, token %s\n", (LineNumber +1), TokenCount, m_cErrorTokenStr);
        
    } else {
        printf("Error %d, Error # not defined\n", ErrorNumber);
        
    }
    // clean up after using the read tokens, you need to free the calloc spaced
    // when you are done with it
    if(gFreeListHead != NULL) { FreeMemoryAllocFront_to_Tail(gFreeListHead); gFreeListHead = NULL;}
    // empty the files to avoid trash print by sybsequent components of the virtual machine
    FILE *fpClean = NULL;
    for (i = 0; i < 1; i++) {
        fpClean = fopen(FILECLEANUP[i],"w");
        fclose(fpClean);
    }
    fpClean = NULL;
    exit(1); // exit 1 to terminate immediatly
    return;
    
}

/*
 *  fixlinesnumbers()
 *  this will reassign the line number in ascending order
 *  by traveling the structure in ascending order
 */
void fixLineNumbers(){
    int i = 0,l = 0;
    int mCall = 0;
    int offset = 0;
    int j = 0;
    // fix the printing line number
    for (j = 0; j <= m_nProcCount ; j++) {
        
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (codeLines[j][i].OP == -1) {
                continue;
            }
            codeLines[j][i].Line = l++;
        }
        
    }
    // fix the call to procedure line
    for (j = 0; j <= m_nProcCount ; j++) {
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (codeLines[j][i].OP == -1) {
                continue;
            }
            // if it is a call to procedure
            // check if it is a initial call or subsequent
            if (codeLines[j][i].OP == cal) {
                mCall = codeLines[j][i].procNumberId;
                if (codeLines[j][i].Called) {
                    codeLines[j][i].M = (codeLines[mCall][1].Line);
                } else {
                    codeLines[j][i].M = (codeLines[mCall][0].Line);
                }
            }
            
        }
        
    }
    
    // fix the call to jpc or jmp lines
    for (j = 0; j <= m_nProcCount ; j++) {
        for (i = 0; i < MAX_CODE_LENGTH; i++) {
            if (codeLines[j][i].OP == -1) {
                continue;
            }
            // if it is a jump conditional
            // check what is the jump offset from the current code line
            if (codeLines[j][i].OP == jpc || codeLines[j][i].OP == jmp) {
                offset = codeLines[j][i].jOffset;
                codeLines[j][i].M = (codeLines[j][i].Line + offset);
            }
            
        }
        
    }
    
    return;
}

// read input token lines count
void InputTokenLines(){
    int c = 0;
    int i = 0;
    int x = 0;
    FILE *lexLine = NULL;
    lexLine = fopen("lexemeline.txt", "r");
    // store each character into -array passed- from main
    while ( (c = fgetc(lexLine)) != EOF ){
        x = ((c - '0') > 0) ? lexemeLine[i++] = (c - '0') : 0;
    }
    fclose(lexLine);
    
    return;
}






